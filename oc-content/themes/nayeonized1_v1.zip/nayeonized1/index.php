<?php
/*
Theme Name: Nayeonized Theme
Theme URI: http://www.osclass.org/
Description: This is a customized OSClass modern theme
Version: 1.0
Author: Nayeon Kim
Author URI: http://www.twitter.com/nayeonkim
Widgets: header,footer
Theme update URI: 
*/

    function modern_theme_info() {
        return array(
             'name'        => 'Nayeonized Theme'
            ,'version'     => '1.0'
            ,'description' => 'This is a customized OSClass modern theme'
            ,'author_name' => 'Nayeon Kim'
            ,'author_url'  => 'http://www.twitter.com/nayeonkim'
            ,'locations'   => array('header', 'footer')
        );
    }

?>